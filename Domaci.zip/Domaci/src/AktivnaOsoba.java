import java.util.Random;

abstract class AktivnaOsoba extends Thread {
    private String ime;

    private long najkraceVreme;
    private long najduzeVreme;
    private PostanskoSanduce sanduce;

    public PostanskoSanduce getSanduce() {
        return sanduce;
    }

    public void setSanduce(PostanskoSanduce sanduce) {
        this.sanduce = sanduce;
    }

    public String getIme() {
        return ime;
    }

    public AktivnaOsoba(String ime, long najkraceVreme, long najduzeVreme, PostanskoSanduce sanduce) {
        this.ime = ime;
        this.najkraceVreme = najkraceVreme;
        this.najduzeVreme = najduzeVreme;
        this.sanduce = sanduce;
    }
public abstract void radi() throws InterruptedException;
public void run(){
    try{
        while(!interrupted()){
            radi();
            sleep((long)(najkraceVreme+Math.random()*(najduzeVreme-najkraceVreme)));
        }
    }catch(InterruptedException e){}
}
    /*public void run() {
        Random random = new Random();
        while (true) {
            try {
                long vreme = najkraceVreme + random.nextInt((int) (najduzeVreme - najkraceVreme + 1));
                Thread.sleep(vreme);
                // Izvrsavanje određene radnje
                System.out.println(ime + " izvrsava radnju. iz aktivne osobe");
            } catch (InterruptedException e) {
                break;
            }
        }
    }*/

    public String toString() {
        return ime + ": " + "\n" + "pridruzeno sanduce"+ ":" + sanduce.stampajPosiljke();
    }
}

