public class Main {
    public static void main(String[] args) {
        try{
        PostanskoSanduce sanduce1 = new PostanskoSanduce("Adresa 1", 5);
        PostanskoSanduce sprimaoca=new PostanskoSanduce("Adresa 2",5);
        sanduce1.dodajPosiljku(new Posiljka("Adresa 2"));
        //System.out.println("dodao sam posiljku iz maina");
        sanduce1.dodajPosiljku(new Posiljka("Adresa 3"));
        //System.out.println("dodao sam posiljku iz maina");

        sanduce1.dodajPosiljku(new Posiljka("Adresa 2"));
        sanduce1.dodajPosiljku(new Posiljka("Adresa 2"));
        //System.out.println("dodao sam posiljku iz maina");
        Postar postar = new Postar("Postar 1", 1000, 5000);
        postar.dodajSanduce(sanduce1);
        postar.dodajSanduceuListu(sprimaoca);
        System.out.println(postar.toString());
        postar.start();
        Thread.sleep(10000);


        System.out.println(sprimaoca.stampajPosiljke()+"posiljke primaoca pre vadjenja");
        Primalac primalac = new Primalac("Primalac 1", 2000, 6000, sprimaoca);

        primalac.start();
        Thread.sleep(10000);
        System.out.println(sprimaoca.stampajPosiljke()+"posiljke primaoca nakon vadjenja(nema ih)");

        postar.interrupt();
        primalac.interrupt();
        System.out.println("unisteni: primalac i postar");

        } catch (InterruptedException e) {}



    }
}
