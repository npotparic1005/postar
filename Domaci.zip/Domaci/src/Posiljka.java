 public class Posiljka  implements Cloneable{
     private static int brojac = 0;
     private int identifikator;
    private String adresa;

    public Posiljka(String adresa) {
        this.identifikator = ++brojac;
        this.adresa = adresa;
    }

    public String getAdresa() {
        return adresa;
    }

     public Posiljka clone() {
         try {
             Posiljka p = (Posiljka) super.clone();
             p.identifikator = ++brojac; return p;
         } catch (CloneNotSupportedException g) { return null; }
     }

     public String toString() {
         return "p_" + identifikator + "[" + adresa + "]";
     }
 }