import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class PostanskoSanduce {
    private String adresa;
    List<Posiljka> posiljke;
    private int kapacitet;
    private static final Object lock = new Object();

    public PostanskoSanduce(String adresa, int kapacitet) {
        this.adresa = adresa;
        this.posiljke = new ArrayList<>();
        this.kapacitet = kapacitet;
    }

    public String getAdresa() {
        return adresa;
    }
    public String stampajPosiljke(){
        String niska = "";
        for (Posiljka p:posiljke){
            niska+= p.toString();
            niska+=" ";
    }
        return niska;
    }


    public void dodajPosiljku(Posiljka posiljka) throws InterruptedException {
        synchronized (lock) {
            if (posiljke.size() < kapacitet) {
                System.out.println("dodajem posiljku u sanduce iz dodajPosiljku");
                posiljke.add(posiljka);
                System.out.println(posiljke+"stampam sve posiljke u sanducetu");
            } else {
                throw new InterruptedException("Puno sanduce, nemoguce dodati posiljku.");
            }
        }
    }

    public Posiljka izvadiPrvuPosiljku() throws InterruptedException {
        synchronized (lock) {
            if (!posiljke.isEmpty()) {
                return posiljke.remove(0);

            } else {
                throw new InterruptedException("Prazno sanduce, nemoguce izvaditi posiljku.");
            }
        }
    }

    public Posiljka izvadiPosiljkuSaAdresom(String adresa) throws InterruptedException {
        synchronized (lock) {
            Iterator<Posiljka> iterator = posiljke.iterator();
            while (iterator.hasNext()) {
                Posiljka posiljka = iterator.next();
                if (posiljka.getAdresa().equals(adresa)) {
                    iterator.remove();
                    return posiljka;
                }
            }
            throw new InterruptedException("Nema posiljke sa zadatom adresom.");
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Posiljka posiljka : posiljke) {
            sb.append(posiljka.toString()).append("\n");
        }
        return sb.toString();
    }
}
