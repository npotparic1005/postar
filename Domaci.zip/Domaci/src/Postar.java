import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Postar extends AktivnaOsoba {
    private List<PostanskoSanduce> sanducici;
    public void dodajSanduceuListu(PostanskoSanduce sanduce){
        sanducici.add(sanduce);
    }

    public Postar(String ime, long najkraceVreme, long najduzeVreme) {
        super(ime, najkraceVreme, najduzeVreme, null);
        this.sanducici = new ArrayList<>();
    }

    public void dodajSanduce(PostanskoSanduce sanduce) {
        super.setSanduce(sanduce);
        System.out.println( " sanduce dodato");

    }
    public String toString(){
        return super.toString();
    }
    public  void radi() throws InterruptedException {
        while (true) {
                List<Posiljka> pomocna=new ArrayList<>();
                Posiljka prva= this.getSanduce().izvadiPrvuPosiljku();
                pomocna.add(prva);
            System.out.println(pomocna+"dodao sam prvu posiljku iz postara");
            String adresa = prva.getAdresa();
                for (Posiljka posiljka : this.getSanduce().posiljke){
                    if (adresa.equals(posiljka.getAdresa())){
                        pomocna.add(posiljka);
                        System.out.println(pomocna+"dodao sam jos jednu posiljku iz postara");
                        System.out.println(pomocna+"ovo je pomocna");
                    }
                }
                for(PostanskoSanduce dostava:this.sanducici){
                    if(adresa.equals(dostava.getAdresa())){for(Posiljka izpomocne:pomocna){
                        System.out.println("dodajem jos jednu posiljku u dostavljenu");
                        dostava.dodajPosiljku(izpomocne);
                        this.getSanduce().izvadiPosiljkuSaAdresom(adresa);}


                    }
                    System.out.println(dostava.stampajPosiljke()+"ovo je dostavljena");
                }
                System.out.println(this.getIme() + " izvrsava radnju.");
        }
    }


    /*
    public void run() {
        Random random = new Random();
        while (true) {
            try {
                long vreme = najkraceVreme + random.nextInt((int) (najduzeVreme - najkraceVreme + 1));
                List<Posiljka> pomocna=new ArrayList<>();
                Posiljka prva= this.sanduce.izvadiPrvuPosiljku();
                pomocna.add(prva);
                String adresa = prva.getAdresa();
                for (Posiljka posiljka : this.sanduce.posiljke){
                    if (adresa.equals(posiljka.getAdresa())){
                        pomocna.add(posiljka);
                        System.out.println(pomocna+"dodao sam jos jednu posiljku iz postara");
                        System.out.println(pomocna+"ovo je pomocna");
                    }
                }
                for(PostanskoSanduce dostava:this.sanducici){
                    if(adresa.equals(dostava.getAdresa())){for(Posiljka izpomocne:pomocna){
                        System.out.println("dodajem jos jednu posiljku u dostavljenu");
                        dostava.dodajPosiljku(izpomocne);
                        this.sanduce.izvadiPosiljkuSaAdresom(adresa);}


                    }
                    System.out.println(dostava.stampajPosiljke()+"ovo je dostavljena");
                }

                System.out.println(ime + " izvrsava radnju.");

                sleep(vreme);

            } catch (InterruptedException e) {
                break;
            }
        }
    }
*/

        }

