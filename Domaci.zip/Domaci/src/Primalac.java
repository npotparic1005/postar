import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Primalac extends AktivnaOsoba {
    private PostanskoSanduce sanduce;

    public Primalac(String ime, long najkraceVreme, long najduzeVreme, PostanskoSanduce sanduce) {
        super(ime, najkraceVreme, najduzeVreme, sanduce);
        this.sanduce = sanduce;
    }

    @Override
    public void radi() throws InterruptedException {
        while (true) {
            try {
                sanduce.izvadiPrvuPosiljku();
                System.out.println(this.getIme() + " izvrsava radnju.");

            } catch (InterruptedException e) {
                break;
            }
        }
    }
/*
   public void run() {
        Random random = new Random();
        while (true) {
            try {
                long vreme = najkraceVreme + random.nextInt((int) (najduzeVreme - najkraceVreme + 1));
                sanduce.izvadiPrvuPosiljku();
                sleep(vreme);
                System.out.println(ime + " izvrsava radnju.");

            } catch (InterruptedException e) {
                break;
            }
        }
    }
*/
}